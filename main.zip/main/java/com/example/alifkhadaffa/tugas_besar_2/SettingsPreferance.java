package com.example.alifkhadaffa.tugas_besar_2;

import android.os.Bundle;

public class SettingsPreferance extends SettingsActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
