package com.example.alifkhadaffa.tugas_besar_2.Model;

import java.util.Random;

public interface Lingkaran {

    float radius = 15;

    void posistion(int height, int width);

}
