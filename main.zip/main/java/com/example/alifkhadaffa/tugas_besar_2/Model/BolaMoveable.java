package com.example.alifkhadaffa.tugas_besar_2.Model;

import java.util.Random;
import com.example.alifkhadaffa.tugas_besar_2.Model.Lingkaran;

public class BolaMoveable implements Lingkaran {

    protected int rad = 30;
    protected int x;
    protected int y;


    public int getX() {
        return x;
    }

    public int getRad(){
        return rad;
    }


    public int getY() {
        return y;
    }

    @Override
    public void posistion(int height, int width) {

    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void move(int newX, int newY){
        this.x = this.x + newX;
        this.y = this.y + newY;
    }




}
