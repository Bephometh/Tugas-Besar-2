package com.example.i16074.tugas_besar_2;

import java.util.Random;

public interface Lingkaran {

    float radius = 50;

    void posistion(int height, int width);

}
