package com.example.i16074.tugas_besar_2;

public class ScoreCounter {
    protected int score;

    public void add() {
        this.score +=100;
    }

    public void setScore() {
        this.score = 0;
    }

    public int getScore() {
        return score;
    }

}
